# ShivShakti Gaming website starter

## Included
- Responsive black-and-gold landing page
- 10% deposit bonus promotional banner
- Login and registration UI demo
- Member dashboard preview with sample wallet and transaction history
- Admin dashboard preview and promotion row

## Important
This is a static front-end prototype. Authentication, user data, wallet, deposits, withdrawals, and admin operations are not connected to a server. Do not use it to collect real passwords or payments. Production use requires a secure backend, database, proper authorization, audit logs, HTTPS, and payment/gaming compliance review.

## Preview locally
Open `index.html` in a modern browser.

## Deploy
1. Extract the ZIP.
2. Upload `index.html` to your hosting provider's public web root (often `public_html`) or deploy the folder using a static host.
3. Connect your domain and enable HTTPS.
4. For a production launch, replace the demo interactions with server-side authentication and authorized API endpoints. Never store admin credentials or payment secrets in front-end JavaScript.
